import ccxt
import time
import json
import os
import sys
import configparser
import logging
from threading import Thread
from datetime import datetime

logging.basicConfig(
    filename='trading_log.txt',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def log(message, level='info'):
    if level == 'info':
        logging.info(message)
    elif level == 'error':
        logging.error(message)
    print(f"{datetime.now()} - {message}")


# =========================================================================
# CONFIGURACIÓN (config.cfg)
# =========================================================================
config = configparser.ConfigParser()
config_path = os.path.join(os.path.dirname(__file__), 'config.cfg')
if not config.read(config_path):
    log("Error: 'config.cfg' no se encontró o no se pudo leer.", level='error')
    sys.exit(1)

if 'BingX' not in config or 'api_key' not in config['BingX'] or 'api_secret' not in config['BingX']:
    log("Error: Claves API no configuradas correctamente en 'config.cfg'.", level='error')
    sys.exit(1)

API_KEY = config['BingX']['api_key']
API_SECRET = config['BingX']['api_secret']

# =========================================================================
# INICIALIZACIÓN DE ccxt PARA BINGX (SWAP)
# =========================================================================
exchange_bingx = ccxt.bingx({
    'apiKey': API_KEY,
    'secret': API_SECRET,
    'enableRateLimit': True,
    'options': {
        'defaultType': 'swap',  # Para perpetuos
    },
    # Descomenta si usas VST (demo):
    # 'headers': {
    #     'X-BX-ACCESS-TYPE': 'VST'
    # },
})

# =========================================================================
# ARCHIVO PARA GUARDAR ESTADO DE ÓRDENES
# =========================================================================
estado_archivo = os.path.join(os.path.dirname(__file__), 'estado_ordenes_bingx.json')
estado_ordenes = {}

def cargar_estado_ordenes():
    global estado_ordenes
    try:
        with open(estado_archivo, 'r') as f:
            estado_ordenes = json.load(f)
        log("Estado de órdenes cargado exitosamente.")
    except (FileNotFoundError, json.JSONDecodeError):
        estado_ordenes = {}
        log("No se encontró archivo de estado o está vacío. Iniciando nuevo.")

def guardar_estado_ordenes():
    try:
        with open(estado_archivo, 'w') as f:
            json.dump(estado_ordenes, f, indent=4)
        log("Estado de órdenes guardado exitosamente.")
    except Exception as e:
        log(f"Error al guardar estado de órdenes: {e}", level='error')


# =========================================================================
# NUEVA FUNCIÓN: BORRAR HISTORIAL DE ÓRDENES
# =========================================================================
def borrar_historial_ordenes():
    """
    Elimina todo el historial en memoria (estado_ordenes) y
    borra el archivo JSON si existe.
    """
    global estado_ordenes
    estado_ordenes = {}  # Vaciar en memoria

    if os.path.isfile(estado_archivo):
        os.remove(estado_archivo)
        log("Archivo de historial de órdenes borrado.")
    else:
        log("No se encontró archivo de historial para borrar.")

    log("Historial de órdenes borrado en memoria.")


# =========================================================================
# LISTAR SÍMBOLOS DE SWAP
# =========================================================================
def listar_simbolos_swap():
    try:
        exchange_bingx.load_markets()
        swap_symbols = []
        for symbol, market in exchange_bingx.markets.items():
            if market.get('swap', False) == True:
                swap_symbols.append(symbol)
        return swap_symbols
    except Exception as e:
        log(f"Error al listar símbolos swap: {e}", level='error')
        return []


# =========================================================================
# CREACIÓN DE ÓRDENES
# =========================================================================
def ejecutar_orden_limiter(simbolo, tipo, precio, cantidad):
    try:
        if tipo.lower() == 'compra':
            orden = exchange_bingx.create_limit_buy_order(simbolo, cantidad, precio)
        elif tipo.lower() == 'venta':
            orden = exchange_bingx.create_limit_sell_order(simbolo, cantidad, precio)
        else:
            raise ValueError("Tipo de orden inválido (usar 'compra' o 'venta').")

        log(f"Orden {tipo.upper()} creada en {simbolo}: Precio={precio}, Cant={cantidad}, ID={orden['id']}")
        return orden
    except Exception as e:
        log(f"Error al crear la orden {tipo} en {simbolo}: {e}", level='error')
        return None


def cancelar_todas_las_ordenes(simbolo=None):
    try:
        if simbolo:
            open_orders = exchange_bingx.fetch_open_orders(symbol=simbolo)
        else:
            open_orders = exchange_bingx.fetch_open_orders()

        for o in open_orders:
            order_id = o['id']
            sym = o['symbol']
            exchange_bingx.cancel_order(order_id, sym)
            log(f"Orden {order_id} en {sym} cancelada exitosamente.")
            for grid_id, grid_data in estado_ordenes.items():
                if grid_data['simbolo'] == sym:
                    if 'ordenes' in grid_data and order_id in grid_data['ordenes']:
                        grid_data['ordenes'].pop(order_id, None)

        guardar_estado_ordenes()
    except Exception as e:
        log(f"Error al cancelar órdenes: {e}", level='error')


# =========================================================================
# CREAR GRILLA BASADA EN NÚMERO DE MONEDAS
# =========================================================================
def crear_grilla_coins(grid_id, simbolo, tipo, precio_entrada, distancia, pasos,
                       total_coins, porcentaje_recompra, stop_loss_price):

    if pasos <= 0:
        log("El número de pasos debe ser mayor que 0.", level='error')
        return

    estado_ordenes[grid_id] = {
        "simbolo": simbolo,
        "tipo_inicial": tipo.lower(),
        "stop_loss_price": stop_loss_price,
        "ordenes": {}
    }

    coins_per_order = total_coins / pasos

    for nivel in range(pasos):
        if tipo.lower() == 'compra':
            precio_nivel = precio_entrada * (1 - (distancia / 100.0) * nivel)
        else:
            precio_nivel = precio_entrada * (1 + (distancia / 100.0) * nivel)

        cantidad_nivel = coins_per_order
        orden_obj = ejecutar_orden_limiter(simbolo, tipo, precio_nivel, cantidad_nivel)
        if orden_obj and 'id' in orden_obj:
            order_id = orden_obj['id']
            estado_ordenes[grid_id]['ordenes'][order_id] = {
                "tipo": tipo,
                "precio": precio_nivel,
                "cantidad": cantidad_nivel,
                "status": "open",
                "recompra_porcentaje": porcentaje_recompra
            }

    guardar_estado_ordenes()
    log(f"Grid {grid_id} creado con {pasos} órdenes en {simbolo}, usando {total_coins} coins. Stop-Loss={stop_loss_price}")


def monitorear_ordenes():
    while True:
        time.sleep(10)
        try:
            for grid_id, grid_data in list(estado_ordenes.items()):
                simbolo = grid_data.get('simbolo')
                stop_loss_price = grid_data.get('stop_loss_price')
                tipo_inicial = grid_data.get('tipo_inicial')

                # STOP-LOSS
                if stop_loss_price and simbolo:
                    try:
                        ticker = exchange_bingx.fetch_ticker(simbolo)
                        last_price = ticker['last']
                    except Exception as ex_ticker:
                        log(f"Error al obtener ticker de {simbolo}: {ex_ticker}", level='error')
                        continue

                    if tipo_inicial == 'compra' and last_price <= stop_loss_price:
                        log(f"[STOP-LOSS] Activado para {grid_id} ({simbolo}). Last Price={last_price}")
                        cancelar_todas_las_ordenes(simbolo)
                        estado_ordenes.pop(grid_id, None)
                        guardar_estado_ordenes()
                        continue

                    if tipo_inicial == 'venta' and last_price >= stop_loss_price:
                        log(f"[STOP-LOSS] Activado para {grid_id} ({simbolo}). Last Price={last_price}")
                        cancelar_todas_las_ordenes(simbolo)
                        estado_ordenes.pop(grid_id, None)
                        guardar_estado_ordenes()
                        continue

                # REVISAR ÓRDENES
                ordenes_dict = grid_data.get('ordenes', {})
                for order_id, order_data in list(ordenes_dict.items()):
                    if order_data.get('status') in ['open', 'pending']:
                        try:
                            orden_api = exchange_bingx.fetch_order(order_id, simbolo)
                            nuevo_status = orden_api['status']
                            order_data['status'] = nuevo_status

                            if nuevo_status == 'closed':
                                log(f"La orden {order_id} del grid {grid_id} se cerró en {simbolo}.")
                                # RECOMPRA INVERSA
                                pct = order_data.get('recompra_porcentaje', 0)
                                if pct > 0:
                                    cantidad_inversa = order_data['cantidad'] * (pct / 100.0)
                                    if cantidad_inversa > 0:
                                        tipo_contrario = 'venta' if order_data['tipo'].lower() == 'compra' else 'compra'
                                        precio_fill = orden_api['price']
                                        orden_contraria = ejecutar_orden_limiter(simbolo, tipo_contrario, precio_fill, cantidad_inversa)
                                        if orden_contraria and 'id' in orden_contraria:
                                            new_id = orden_contraria['id']
                                            ordenes_dict[new_id] = {
                                                "tipo": tipo_contrario,
                                                "precio": precio_fill,
                                                "cantidad": cantidad_inversa,
                                                "status": "open",
                                                "recompra_porcentaje": 0
                                            }
                        except Exception as ex_fetch:
                            log(f"Error al consultar orden {order_id} en {simbolo}: {ex_fetch}", level='error')

            guardar_estado_ordenes()

        except Exception as e:
            log(f"Error general al monitorear órdenes: {e}", level='error')


# Inicialización
exchange_bingx.load_markets()
cargar_estado_ordenes()
Thread(target=monitorear_ordenes, daemon=True).start()
